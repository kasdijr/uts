<?php
    //koneksi Database
    $server = "localhost";
    $user = "root";
    $pass = "";
    $database = "db_pendataan";

    $index2 = mysqli_connect($server, $user, $pass, $database) or die(mysqli_error($index2));

    //jika tombol simpan dikelik
    if(isset($_POST['bsimpan']))
    {
        //pengujian apakah data akan diedit atau di simpan baru
        if($_GET['hal'] == "edit")
        {
            //data akan di edit
            $edit = mysqli_query($index2, "UPDATE tmhs set 
                                                nim ='$_POST[tnim]',
                                                nama ='$_POST[tnama]', 
                                                alamat ='$_POST[tkelamin]',
                                                prodi='$_POST[tprodi]' 
                                            WHERE id_mhs = '$_GET[id]'");
         if($edit) //jika edit sukses
         {
            echo "<script>
                    alert('Edit data suksess!');
                    document.location.herf='index.php'
                  </script>";
         }
         else
         {
            echo "<script>
                    alert('Edit data Gagal!');
                    document.location.herf='index.php'
                  </script>";
         }
    }
    else
    {
        //data akan di simpan baru
        $simpan = mysqli_query($index2, "INSERT INTO tmhs ( nim, nama , alamat, prodi )
                                          VALUES ('$_POST[tnim]',
                                                 '$_POST[tnama]',
                                                 '$_POST[tkelamin]', 
                                                 '$_POST[tprodi]')
                                          ");
     if($simpan) //jika simpan sukses
     {
        echo "<script>
                alert('Simpan data suksess!');
                document.location='index.php';
              </script>";
     }
     else
     {
        echo "<script>
                alert('Simpan data Gagal!');
                document.location='index.php';
              </script>";
     }
        }


        
    }

        //pengujian jika tombol edit / hapus di  klik
    if(isset($_GET['hal']))
    {
        //penguji jika edit data
        if($_GET['hal'] == "edit")
        {
            $id = $_GET['id'];
            //tampilkan data yang akan di edit
            $tampil = mysqli_query($index2,"SELECT * FROM tmhs WHERE id_mhs = $_GET[id]");
            $data= mysqli_fetch_array($tampil);
            if($data)
            {
                //jika data ditemukan,maka data di tampung ke dalam variabel
                $vnama = $data['nama'];
                $vkelamin = $data['alamat'];
                $vprodi = $data['prodi'];
            }
        }
        else if ($_GET['hal'] == "hapus")
        {
            //persiapan hapus data
            $hapus = mysqli_query($index2, "DELETE FROM tmhs WHERE id_mhs = '$_GET[id]' ");
            if($hapus){
                echo "<script>
                alert('Hapus data sukses!');
                document.location='index.php';
              </script>";
            }
        }
    }

 
?>

<!DOCTYPE html>
<html>
<head>
    <title> document </title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">

    <h1 class="text-center" style="color:white;">North Atlantic Treaty Organization (NATO)  </h1>

    <!--.Awal card form.-->
    <div class="card mt-3 ">
        <div class="card-header bg-primary text-white ">
            input data negara nato
        </div>
        <div class="card-body">
            <form method="post" action="">
            <div class="form-group">
                    <label>NAME</label>
                    <input type="text" name="tnama"  value="<?=@$vnama?>" class="form-control" placeholder="Nama warga negara" required>
                </div>
            <div class="form-group">
                    <label>GANDER</label>
                    <select class="form-control" name="tkelamin">
                    <option selected disabled></option>
                        <?php if($vkelamin == 'Man') : ?>
                        <option value="Man" selected>Man</option>
                        <?php else : ?>
                        <option value="Man">Man</option>
                        <?php endif ?>
                        <option selected disabled></option>
                        <?php if($vkelamin == 'Woman') : ?>
                        <option value="Woman" selected>Woman</option>
                        <?php else : ?>
                        <option value="Woman">Woman</option>
                        <?php endif ?>
                    </select>
                </div>
            <div class="form-group">
                    <label>COUNTRY</label>
                    <select class="form-control" name="tprodi">
                        <option selected disabled></option>
                        <?php if(@$vprodi == 'amerika seerikat') : ?>
                        <option value="amerika serikat" selected>amerika serikat</option>
                        <?php else : ?>
                        <option value="amerika serikat">amerika serikat</option>
                        <?php endif ?>
                        <?php if(@$vprodi == 'inggris') : ?>
                        <option value="inggris" selected>inggris</option>
                        <?php else : ?>
                        <option value="inggris">inggris</option>
                        <?php endif ?>
                        <?php if(@$vprodi == 'kanada') : ?>
                        <option value="kanada" selected>kanada</option>
                        <?php else : ?>
                        <option value="kanada">kanada</option>
                        <?php endif ?>
                        <?php if(@$vprodi == 'perancis') : ?>
                        <option value="perancis" selected>perancis</option>
                        <?php else : ?>
                        <option value="perancis">perancis</option>
                        <?php endif ?>
                        <?php if(@$vprodi == 'belanda') : ?>
                        <option value="belanda" selected>belanda</option>
                        <?php else : ?>
                        <option value="belanda">belanda</option>
                        <?php endif ?>
                        <?php if(@$vprodi == 'itali') : ?>
                        <option value="itali" selected>itali</option>
                        <?php else : ?>
                        <option value="itali">itali</option>
                        <?php endif ?>
                        <?php if(@$vprodi == 'portugal') : ?>
                        <option value="portugal" selected>portugal</option>
                        <?php else : ?>
                        <option value="portugal">portugal</option>
                        <?php endif ?>
                        <?php if(@$vprodi == 'denmark') : ?>
                        <option value="denmark" selected>denmark</option>
                        <?php else : ?>
                        <option value="denmark">denmark</option>
                        <?php endif ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-success" name="bsimpan">Peroses</button>
                
            </form>
        </div>
    </div>
    <!--.Akhir card form.-->

    <!--.Awal card tabel.-->
    <div class="card mt-3 ">
        <div class="card-header bg-success text-white">
            Warga Negara
        </div>
        <div class="card-body">

            <table class="table table-bordered table-striped ">
                <tr>
                    <th>NO</th>
                    <th>Nama</th>
                    <th>Kelamin</th>
                    <th>Negara</th>
                    <th>Informasi</th>
                </tr>
                <?php
                    $no = 1;
                    $tampil = mysqli_query($index2, "SELECT * from tmhs order by id_mhs desc");
                    while($data = mysqli_fetch_array($tampil)) :
                ?>
                <tr>
                    <td><?=$no++;?></td>
                    <td><?=$data['nama']?></td>
                    <td><?=$data['alamat']?></td>
                    <td><?=$data['prodi']?></td>
                    <td>
                        <a href="index.php?hal=edit&id=<?=$data['id_mhs']?>" class="btn btn-warning"> edit </a>
                        <a href="index.php?hal=hapus&id=<?=$data['id_mhs']?>" onclick="return confirm('Apakah yakin ingin menghapus data diri ini?')" class="btn btn-danger"> Hapus </a>
                    </td>
                    
                </tr>
            <?php endwhile;
            ?>
            </table>
            
        </div>
    </div>
    <!--.Akhir card tabel.-->

</div>
<script type="text/javascript" src>"js/bootstrap.min.js"</script>
</body>
</html>
